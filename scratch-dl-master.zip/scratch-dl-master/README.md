# scratch-dl
scratch-dl is a scratch.mit.edu downloader/archiver
In its current state, it works for single projects and entire userprofiles, but supports no options and customizability, so you will have to modify the code yourself if you wish to get it to do something
